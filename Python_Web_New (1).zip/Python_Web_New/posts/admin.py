from django.contrib import admin
from posts.models import Sport,Post, Comment

admin.site.register(Sport)
admin.site.register(Post)
admin.site.register(Comment)
# Register your models here.
